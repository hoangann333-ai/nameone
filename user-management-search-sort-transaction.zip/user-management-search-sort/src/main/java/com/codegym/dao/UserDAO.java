package com.codegym.dao;

import com.codegym.model.User;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/** JDBC DAO. User row and permission assignments are committed or rolled back together. */
public class UserDAO implements IUserDAO {
    private final String jdbcUrl;
    private final String dbUser;
    private final String dbPassword;

    public UserDAO(String jdbcUrl, String dbUser, String dbPassword) {
        this.jdbcUrl = jdbcUrl;
        this.dbUser = dbUser;
        this.dbPassword = dbPassword;
    }

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(jdbcUrl, dbUser, dbPassword);
    }

    @Override
    public List<User> findUsers(String country, String sortDirection) throws SQLException {
        String direction = "DESC".equalsIgnoreCase(sortDirection) ? "DESC" : "ASC";
        String countryFilter = country == null ? "" : country.trim();
        boolean filter = !countryFilter.isEmpty();
        String sql = "SELECT id, name, email, country FROM users "
                + (filter ? "WHERE country LIKE ? " : "")
                + "ORDER BY name " + direction + ", id ASC";

        List<User> users = new ArrayList<>();
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            if (filter) statement.setString(1, "%" + countryFilter + "%");
            try (ResultSet result = statement.executeQuery()) {
                while (result.next()) {
                    users.add(new User(result.getInt("id"), result.getString("name"),
                            result.getString("email"), result.getString("country")));
                }
            }
        }
        return users;
    }

    @Override
    public void addUserTransaction(User user, int[] permissionIds) throws SQLException {
        try (Connection connection = getConnection()) {
            boolean originalAutoCommit = connection.getAutoCommit();
            connection.setAutoCommit(false);
            try {
                int userId;
                String insertUserSql = "INSERT INTO users (name, email, country) VALUES (?, ?, ?)";
                try (PreparedStatement userStatement = connection.prepareStatement(
                        insertUserSql, Statement.RETURN_GENERATED_KEYS)) {
                    userStatement.setString(1, user.getName());
                    userStatement.setString(2, user.getEmail());
                    userStatement.setString(3, user.getCountry());
                    if (userStatement.executeUpdate() != 1) {
                        throw new SQLException("Không thể thêm người dùng.");
                    }
                    try (ResultSet keys = userStatement.getGeneratedKeys()) {
                        if (!keys.next()) throw new SQLException("MySQL không trả về ID người dùng mới.");
                        userId = keys.getInt(1);
                    }
                }

                if (permissionIds != null && permissionIds.length > 0) {
                    String insertPermissionSql =
                            "INSERT INTO user_permission (user_id, permission_id) VALUES (?, ?)";
                    try (PreparedStatement permissionStatement = connection.prepareStatement(insertPermissionSql)) {
                        for (int permissionId : permissionIds) {
                            permissionStatement.setInt(1, userId);
                            permissionStatement.setInt(2, permissionId);
                            permissionStatement.addBatch();
                        }
                        permissionStatement.executeBatch();
                    }
                }
                connection.commit();
            } catch (SQLException | RuntimeException failure) {
                try {
                    connection.rollback();
                } catch (SQLException rollbackFailure) {
                    failure.addSuppressed(rollbackFailure);
                }
                throw failure;
            } finally {
                connection.setAutoCommit(originalAutoCommit);
            }
        }
    }
}
