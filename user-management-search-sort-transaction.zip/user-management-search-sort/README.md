# User Management: JDBC Transaction

Bài mẫu JSP/Servlet/JDBC/MySQL chạy với Java 17 và Tomcat 10.1+. Project có chức năng tìm User theo country, sắp xếp theo name và thêm User cùng nhiều quyền trong một transaction.

## Cài đặt và chạy
1. Mở `database.sql` trong MySQL Workbench và chạy. Nếu đã có database `demo` cùng bảng `users`, kiểm tra bảng đó có các cột `id` (AUTO_INCREMENT), `name`, `email`, `country`, và dùng InnoDB. Script tạo thêm `permission`, `user_permission` và dữ liệu quyền.
2. Trong `src/main/webapp/WEB-INF/web.xml`, sửa `jdbcUsername` và `jdbcPassword` theo MySQL của bạn.
3. Cài Maven và JDK 17, tại thư mục project chạy `mvn clean package`.
4. Copy `target/user-management-search-sort.war` vào `webapps` của Tomcat 10.1+ rồi khởi động Tomcat.
5. Truy cập `http://localhost:8080/user-management-search-sort/users`; chọn **Thêm người dùng**, điền thông tin và chọn các quyền.

## Phần transaction
`UserDAO.addUserTransaction()` tắt auto-commit, thêm User và lấy ID sinh tự động, thêm các dòng `user_permission`, rồi commit. Nếu một thao tác SQL lỗi, DAO rollback và ném lỗi lên Servlet; không nuốt lỗi. Cả ba bảng dùng InnoDB để MySQL hỗ trợ rollback.

## Kiểm tra
Chạy sau khi gửi form thành công:
```sql
SELECT * FROM users ORDER BY id DESC LIMIT 1;
SELECT up.user_id, p.id, p.name
FROM user_permission up JOIN permission p ON p.id = up.permission_id
ORDER BY up.user_id DESC, p.id;
```
Để thử rollback, tạm thời chọn permission ID không tồn tại trong `UserServlet` hoặc tắt FK trong script kiểm thử có chủ đích; sau lỗi, dòng User mới cũng không được giữ lại.
