package com.codegym.controller;

import com.codegym.dao.IUserDAO;
import com.codegym.dao.UserDAO;
import com.codegym.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@WebServlet(name = "UserServlet", urlPatterns = {"/users"})
public class UserServlet extends HttpServlet {
    private IUserDAO userDAO;

    @Override
    public void init() throws ServletException {
        String url = getServletContext().getInitParameter("jdbcURL");
        String username = getServletContext().getInitParameter("jdbcUsername");
        String password = getServletContext().getInitParameter("jdbcPassword");
        if (url == null || username == null || password == null) {
            throw new ServletException("Thiếu cấu hình jdbcURL/jdbcUsername/jdbcPassword trong web.xml");
        }
        userDAO = new UserDAO(url, username, password);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        if ("create".equals(request.getParameter("action"))) {
            request.getRequestDispatcher("/WEB-INF/views/create.jsp").forward(request, response);
            return;
        }
        String country = request.getParameter("country");
        String sort = "DESC".equalsIgnoreCase(request.getParameter("sort")) ? "DESC" : "ASC";
        try {
            request.setAttribute("users", userDAO.findUsers(country, sort));
            request.setAttribute("country", country == null ? "" : country.trim());
            request.setAttribute("sort", sort);
            request.setAttribute("success", "1".equals(request.getParameter("created")));
            request.getRequestDispatcher("/WEB-INF/views/users.jsp").forward(request, response);
        } catch (SQLException e) {
            throw new ServletException("Không thể truy vấn danh sách người dùng", e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        if (!"insertUser".equals(request.getParameter("action"))) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Action không hợp lệ");
            return;
        }
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String country = request.getParameter("country");
        String[] values = request.getParameterValues("permissions");
        List<Integer> selectedIds = new ArrayList<>();
        try {
            if (values != null) {
                for (String value : values) {
                    int id = Integer.parseInt(value);
                    if (id < 1 || id > 4) throw new IllegalArgumentException("Quyền không hợp lệ");
                    if (!selectedIds.contains(id)) selectedIds.add(id);
                }
            }
        } catch (IllegalArgumentException e) {
            showCreateError(request, response, "Danh sách quyền không hợp lệ.");
            return;
        }
        if (name == null || name.isBlank() || email == null || email.isBlank()
                || country == null || country.isBlank()) {
            showCreateError(request, response, "Vui lòng nhập đầy đủ họ tên, email và quốc gia.");
            return;
        }
        int[] permissionIds = selectedIds.stream().mapToInt(Integer::intValue).toArray();
        try {
            userDAO.addUserTransaction(new User(name.trim(), email.trim(), country.trim()), permissionIds);
            response.sendRedirect(request.getContextPath() + "/users?created=1");
        } catch (SQLException e) {
            request.setAttribute("error", "Không lưu được dữ liệu. Giao dịch đã được hủy nếu có lỗi: " + e.getMessage());
            request.setAttribute("name", name);
            request.setAttribute("email", email);
            request.setAttribute("country", country);
            request.getRequestDispatcher("/WEB-INF/views/create.jsp").forward(request, response);
        }
    }

    private void showCreateError(HttpServletRequest request, HttpServletResponse response, String message)
            throws ServletException, IOException {
        request.setAttribute("error", message);
        request.setAttribute("name", request.getParameter("name"));
        request.setAttribute("email", request.getParameter("email"));
        request.setAttribute("country", request.getParameter("country"));
        request.getRequestDispatcher("/WEB-INF/views/create.jsp").forward(request, response);
    }
}
